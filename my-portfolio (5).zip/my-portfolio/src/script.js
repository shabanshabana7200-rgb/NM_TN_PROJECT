<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Portfolio</title>
 
     
</head>
<body>

<header>
    <h1>My Portfolio</h1>
    <h2>S. Shabana</h2>
    <p>Computer Application Student</p>
    <img src="profile.jpg" alt="Profile Photo">
</header>

<nav>
    <a href="#about">About</a>
    <a href="#education">Education</a>
    <a href="#skills">Skills</a>
    <a href="#projects">Projects</a>
    <a href="#contact">Contact</a>
</nav>

<section id="about">
    <h2>About Me</h2>
    <p>Hello! I am Shabana, a passionate Computer Application student with a strong interest in programming languages like C++ and Python. I enjoy building creative and functional web applications.</p>
</section>

<section id="education">
    <h2>Education</h2>
    <ul>
        <li><b>Bachelor of Computer Application </b> - Vidhya Sagar Women's College (2024 - 2027)</li>
        <li><b>High School</b> -  Government Girls Higher Secondary School (2022 - 2024)</li>
    </ul>
</section>

<section id="skills" class="skills">
    <h2>Skills</h2>
    <span>HTML</span>
    <span>CSS</span>
    <span>JavaScript</span>
    <span>Python</span>
    <span>C++</span>
</section>

<section id="projects">
    <h2>Projects</h2>
    <ul>
        <li><b>Portfolio Website</b> - A responsive personal portfolio using HTML, CSS, and JS.</li>
        <li><b>Student Management System</b> - A Python-based desktop application.</li>
    </ul>
</section>

<section id="contact">
    <h2>Contact</h2>
    <p>Email: <a href="mailto:shabanshabana720@gmail.com">shabanshabana7200@gmail.com</a></p>
    <p>Phone: +91-7200824460</p>
    <p>LinkedIn: <a href="#" target="_blank">linkedin.com/in/shabana/a></p>
</section>

<footer>
    <p>&copy; 2025 Shabana | All Rights Reserved</p>
</footer>

<!-- Back to Top Button -->
<button id="backToTop">↑ Top</button>

<script>
    // Show "Back to Top" button when scrolling down
    const backToTop = document.getElementById('backToTop');
    window.onscroll = function() {
        if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
            backToTop.style.display = 'block';
        } else {
            backToTop.style.display = 'none';
        }
    };

    // Scroll to top when button clicked
    backToTop.onclick = function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };
</script>

</body>
</html>